{{
  config(
    materialized='ephemeral'
    )
}}

select * from {{ ref('any_type_column_anomalies_training') }}