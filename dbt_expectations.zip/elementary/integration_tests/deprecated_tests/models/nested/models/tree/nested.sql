select 1 as one
