select * from {{ ref("numeric_column_anomalies") }}
