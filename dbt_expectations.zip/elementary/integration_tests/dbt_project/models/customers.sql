 select * from {{ ref('stg_customers') }}
