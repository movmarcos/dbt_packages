#!/usr/bin/env bash

export DBT_EDR_DEBUG=1
export DBT_MACRO_DEBUGGING=1

