{% macro dbg() %}
  {% do debug() %}
{% endmacro %}
